lineage_palette <- c("Lineage 1" = "#E487B0",
                     "Lineage 2" = "#016BB5",
                     "Lineage 3" = "#9661A7",
                     "Lineage 4" = "#E3553A",
                     "Lineage 5" = "#60B779",
                     "Lineage 6" = "#60B779",
                     "africanum" = "#60B779",
                     "Lineage 7" = "#FFB40C",
                     "Animal-adapted" = "#6F421B",
                     "Mycobacterium bovis" = "#6F421B",
                     "Undetermined" = "#d1d1d1",
                     "Mixed" = "#d1d1d1",
                     ";" = "#d1d1d1",
                     "NA" = "#d1d1d1"
)
lineage_names <- names(lineage_palette)

closest_lineage <- function(lineage_string, lineage_names = lineage_names){
  # Calculates for a given string that is supposed to describe a lineage,
  # which one is the closest lineage within lineage_palette
  lin_index <- which(stringdist::stringsim(lineage_string, lineage_names) ==
          max(stringdist::stringsim(lineage_string, lineage_names)))
  if (is.na(lineage_string)){
    return("NA")
  }
  return(lineage_names[lin_index])
}

MTBC_colors <- function  (user_lineages){
  # For a vector with strings that describe MTBC lineages, guess which lineages
  # within lineage_palette are present, and create the corresponding palette
  user_lineages <- unique(user_lineages)
  corresponding_lineages <- unlist(lapply(user_lineages,
                FUN = closest_lineage,
                lineage_names = lineage_names))
  corresponding_palette <- lineage_palette[corresponding_lineages]
  names(corresponding_palette) <- user_lineages
  return(corresponding_palette)
}
